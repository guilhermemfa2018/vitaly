﻿namespace Teste_Gerenciamento_de_Digitais_REP3
{
    partial class GerenciarDigitaisREP3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerenciarDigitaisREP3));
            this.btLerTempIndividual = new System.Windows.Forms.Button();
            this.btGravarTempIndividual = new System.Windows.Forms.Button();
            this.TBListaUsuarios = new System.Windows.Forms.DataGridView();
            this.Ncracha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuantTemplates = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.btListarUsuarios = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.campoTemplateConcatenado = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.cxCadNTemplate1 = new System.Windows.Forms.TextBox();
            this.cxCadTemplate1 = new System.Windows.Forms.TextBox();
            this.btconverter = new System.Windows.Forms.Button();
            this.btcp_cxCadTemplate5 = new System.Windows.Forms.Button();
            this.btcp_cxCadTemplate4 = new System.Windows.Forms.Button();
            this.cxCadNTemplate3 = new System.Windows.Forms.TextBox();
            this.cxCadTemplate3 = new System.Windows.Forms.TextBox();
            this.btcp_cxCadTemplate3 = new System.Windows.Forms.Button();
            this.cxCadNTemplate2 = new System.Windows.Forms.TextBox();
            this.cxCadTemplate2 = new System.Windows.Forms.TextBox();
            this.btcp_cxCadTemplate2 = new System.Windows.Forms.Button();
            this.cxCadNTemplate4 = new System.Windows.Forms.TextBox();
            this.cxCadTemplate4 = new System.Windows.Forms.TextBox();
            this.cxCadNTemplate5 = new System.Windows.Forms.TextBox();
            this.cxCadTemplate5 = new System.Windows.Forms.TextBox();
            this.btcp_cxCadTemplate1 = new System.Windows.Forms.Button();
            this.QuantTemplatesLidos = new System.Windows.Forms.TextBox();
            this.textoIMG = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cxPorta = new System.Windows.Forms.TextBox();
            this.cxCPF = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cxSenha = new System.Windows.Forms.TextBox();
            this.cxIp = new System.Windows.Forms.TextBox();
            this.cxNumSerie = new System.Windows.Forms.TextBox();
            this.TxCopiado = new System.Windows.Forms.Label();
            this.btcp_cxLerTemplate5 = new System.Windows.Forms.Button();
            this.btcp_cxLerTemplate4 = new System.Windows.Forms.Button();
            this.btcp_cxLerTemplate3 = new System.Windows.Forms.Button();
            this.btcp_cxLerTemplate2 = new System.Windows.Forms.Button();
            this.CpCL_cxGravarTemplate5 = new System.Windows.Forms.Button();
            this.CpCL_cxGravarTemplate4 = new System.Windows.Forms.Button();
            this.CpCL_cxGravarTemplate3 = new System.Windows.Forms.Button();
            this.CpCL_cxGravarTemplate2 = new System.Windows.Forms.Button();
            this.CpCL_cxGravarTemplate1 = new System.Windows.Forms.Button();
            this.btcp_cxLerTemplate1 = new System.Windows.Forms.Button();
            this.cxGravarTemplate5 = new System.Windows.Forms.TextBox();
            this.cxLerTemplate5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cxGravarTemplate4 = new System.Windows.Forms.TextBox();
            this.cxLerTemplate4 = new System.Windows.Forms.TextBox();
            this.cxGravarTemplate2 = new System.Windows.Forms.TextBox();
            this.cxLerTemplate2 = new System.Windows.Forms.TextBox();
            this.cxGravarTemplate3 = new System.Windows.Forms.TextBox();
            this.cxLerTemplate3 = new System.Windows.Forms.TextBox();
            this.cxGravarTemplate1 = new System.Windows.Forms.TextBox();
            this.cxLerTemplate1 = new System.Windows.Forms.TextBox();
            this.cxNumPIS = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btExportarFunc = new System.Windows.Forms.Button();
            this.btExcluirUsuario = new System.Windows.Forms.Button();
            this.verificarConexao = new System.Windows.Forms.Button();
            this.btLimparLer = new System.Windows.Forms.Button();
            this.btLimparGravar = new System.Windows.Forms.Button();
            this.btGravarTempConcatenado = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.TBListaUsuarios)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btLerTempIndividual
            // 
            this.btLerTempIndividual.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btLerTempIndividual.BackColor = System.Drawing.Color.White;
            this.btLerTempIndividual.Enabled = false;
            this.btLerTempIndividual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLerTempIndividual.Location = new System.Drawing.Point(660, 240);
            this.btLerTempIndividual.Name = "btLerTempIndividual";
            this.btLerTempIndividual.Size = new System.Drawing.Size(106, 23);
            this.btLerTempIndividual.TabIndex = 1;
            this.btLerTempIndividual.Text = "Ler Templates";
            this.btLerTempIndividual.UseVisualStyleBackColor = false;
            this.btLerTempIndividual.Click += new System.EventHandler(this.btLerTempIndividual_Click);
            // 
            // btGravarTempIndividual
            // 
            this.btGravarTempIndividual.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btGravarTempIndividual.BackColor = System.Drawing.Color.White;
            this.btGravarTempIndividual.Enabled = false;
            this.btGravarTempIndividual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGravarTempIndividual.Location = new System.Drawing.Point(660, 386);
            this.btGravarTempIndividual.Name = "btGravarTempIndividual";
            this.btGravarTempIndividual.Size = new System.Drawing.Size(106, 23);
            this.btGravarTempIndividual.TabIndex = 1;
            this.btGravarTempIndividual.Text = "Gravar Templates";
            this.btGravarTempIndividual.UseVisualStyleBackColor = false;
            this.btGravarTempIndividual.Click += new System.EventHandler(this.btGravarTempIndividual_Click);
            // 
            // TBListaUsuarios
            // 
            this.TBListaUsuarios.AllowUserToAddRows = false;
            this.TBListaUsuarios.AllowUserToDeleteRows = false;
            this.TBListaUsuarios.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.TBListaUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TBListaUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ncracha,
            this.QuantTemplates});
            this.TBListaUsuarios.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.TBListaUsuarios.Location = new System.Drawing.Point(9, 42);
            this.TBListaUsuarios.MultiSelect = false;
            this.TBListaUsuarios.Name = "TBListaUsuarios";
            this.TBListaUsuarios.ReadOnly = true;
            this.TBListaUsuarios.RowHeadersVisible = false;
            this.TBListaUsuarios.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TBListaUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TBListaUsuarios.Size = new System.Drawing.Size(173, 281);
            this.TBListaUsuarios.TabIndex = 5;
            this.TBListaUsuarios.Click += new System.EventHandler(this.TBListaUsuarios_Click);
            // 
            // Ncracha
            // 
            this.Ncracha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Ncracha.FillWeight = 90F;
            this.Ncracha.HeaderText = "PIS";
            this.Ncracha.Name = "Ncracha";
            this.Ncracha.ReadOnly = true;
            // 
            // QuantTemplates
            // 
            this.QuantTemplates.HeaderText = "N. Bio";
            this.QuantTemplates.Name = "QuantTemplates";
            this.QuantTemplates.ReadOnly = true;
            this.QuantTemplates.Width = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Lista funcionarios do REP";
            // 
            // btListarUsuarios
            // 
            this.btListarUsuarios.BackColor = System.Drawing.Color.White;
            this.btListarUsuarios.Enabled = false;
            this.btListarUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btListarUsuarios.Location = new System.Drawing.Point(9, 325);
            this.btListarUsuarios.Name = "btListarUsuarios";
            this.btListarUsuarios.Size = new System.Drawing.Size(173, 23);
            this.btListarUsuarios.TabIndex = 8;
            this.btListarUsuarios.Text = "Listar Funcionários";
            this.btListarUsuarios.UseVisualStyleBackColor = false;
            this.btListarUsuarios.Click += new System.EventHandler(this.btListarUsuarios_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.campoTemplateConcatenado);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.cxCadNTemplate1);
            this.groupBox1.Controls.Add(this.cxCadTemplate1);
            this.groupBox1.Controls.Add(this.btconverter);
            this.groupBox1.Controls.Add(this.btcp_cxCadTemplate5);
            this.groupBox1.Controls.Add(this.btcp_cxCadTemplate4);
            this.groupBox1.Controls.Add(this.cxCadNTemplate3);
            this.groupBox1.Controls.Add(this.cxCadTemplate3);
            this.groupBox1.Controls.Add(this.btcp_cxCadTemplate3);
            this.groupBox1.Controls.Add(this.cxCadNTemplate2);
            this.groupBox1.Controls.Add(this.cxCadTemplate2);
            this.groupBox1.Controls.Add(this.btcp_cxCadTemplate2);
            this.groupBox1.Controls.Add(this.cxCadNTemplate4);
            this.groupBox1.Controls.Add(this.cxCadTemplate4);
            this.groupBox1.Controls.Add(this.cxCadNTemplate5);
            this.groupBox1.Controls.Add(this.cxCadTemplate5);
            this.groupBox1.Controls.Add(this.btcp_cxCadTemplate1);
            this.groupBox1.Controls.Add(this.QuantTemplatesLidos);
            this.groupBox1.Controls.Add(this.textoIMG);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(12, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(773, 164);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastro de digitais através pelo leitor USB";
            // 
            // campoTemplateConcatenado
            // 
            this.campoTemplateConcatenado.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.campoTemplateConcatenado.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.campoTemplateConcatenado.Location = new System.Drawing.Point(385, 139);
            this.campoTemplateConcatenado.Name = "campoTemplateConcatenado";
            this.campoTemplateConcatenado.Size = new System.Drawing.Size(329, 18);
            this.campoTemplateConcatenado.TabIndex = 12;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::Teste_Gerenciamento_de_Digitais_REP3.Properties.Resources.tap;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(9, 21);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(124, 111);
            this.button3.TabIndex = 14;
            this.button3.Text = "Leitura Única";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Teste_Gerenciamento_de_Digitais_REP3.Properties.Resources.fingerprint;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(134, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(102, 111);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::Teste_Gerenciamento_de_Digitais_REP3.Properties.Resources.hand;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(250, 21);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(124, 111);
            this.button4.TabIndex = 14;
            this.button4.Text = "Leitura com interface";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cxCadNTemplate1
            // 
            this.cxCadNTemplate1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cxCadNTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadNTemplate1.Location = new System.Drawing.Point(403, 38);
            this.cxCadNTemplate1.Name = "cxCadNTemplate1";
            this.cxCadNTemplate1.ReadOnly = true;
            this.cxCadNTemplate1.Size = new System.Drawing.Size(17, 18);
            this.cxCadNTemplate1.TabIndex = 12;
            // 
            // cxCadTemplate1
            // 
            this.cxCadTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxCadTemplate1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxCadTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadTemplate1.Location = new System.Drawing.Point(420, 38);
            this.cxCadTemplate1.Name = "cxCadTemplate1";
            this.cxCadTemplate1.ReadOnly = true;
            this.cxCadTemplate1.Size = new System.Drawing.Size(294, 18);
            this.cxCadTemplate1.TabIndex = 12;
            // 
            // btconverter
            // 
            this.btconverter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btconverter.BackColor = System.Drawing.Color.White;
            this.btconverter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btconverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btconverter.Location = new System.Drawing.Point(719, 137);
            this.btconverter.Name = "btconverter";
            this.btconverter.Size = new System.Drawing.Size(47, 21);
            this.btconverter.TabIndex = 13;
            this.btconverter.Text = "Iniciar";
            this.btconverter.UseVisualStyleBackColor = false;
            this.btconverter.Click += new System.EventHandler(this.btconverter_Click);
            // 
            // btcp_cxCadTemplate5
            // 
            this.btcp_cxCadTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxCadTemplate5.BackColor = System.Drawing.Color.White;
            this.btcp_cxCadTemplate5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxCadTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxCadTemplate5.Location = new System.Drawing.Point(719, 113);
            this.btcp_cxCadTemplate5.Name = "btcp_cxCadTemplate5";
            this.btcp_cxCadTemplate5.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxCadTemplate5.TabIndex = 13;
            this.btcp_cxCadTemplate5.Text = "Copiar";
            this.btcp_cxCadTemplate5.UseVisualStyleBackColor = false;
            this.btcp_cxCadTemplate5.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // btcp_cxCadTemplate4
            // 
            this.btcp_cxCadTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxCadTemplate4.BackColor = System.Drawing.Color.White;
            this.btcp_cxCadTemplate4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxCadTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxCadTemplate4.Location = new System.Drawing.Point(719, 94);
            this.btcp_cxCadTemplate4.Name = "btcp_cxCadTemplate4";
            this.btcp_cxCadTemplate4.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxCadTemplate4.TabIndex = 13;
            this.btcp_cxCadTemplate4.Text = "Copiar";
            this.btcp_cxCadTemplate4.UseVisualStyleBackColor = false;
            this.btcp_cxCadTemplate4.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // cxCadNTemplate3
            // 
            this.cxCadNTemplate3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cxCadNTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadNTemplate3.Location = new System.Drawing.Point(403, 76);
            this.cxCadNTemplate3.Name = "cxCadNTemplate3";
            this.cxCadNTemplate3.ReadOnly = true;
            this.cxCadNTemplate3.Size = new System.Drawing.Size(17, 18);
            this.cxCadNTemplate3.TabIndex = 12;
            // 
            // cxCadTemplate3
            // 
            this.cxCadTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxCadTemplate3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxCadTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadTemplate3.Location = new System.Drawing.Point(420, 76);
            this.cxCadTemplate3.Name = "cxCadTemplate3";
            this.cxCadTemplate3.ReadOnly = true;
            this.cxCadTemplate3.Size = new System.Drawing.Size(294, 18);
            this.cxCadTemplate3.TabIndex = 12;
            // 
            // btcp_cxCadTemplate3
            // 
            this.btcp_cxCadTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxCadTemplate3.BackColor = System.Drawing.Color.White;
            this.btcp_cxCadTemplate3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxCadTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxCadTemplate3.Location = new System.Drawing.Point(719, 75);
            this.btcp_cxCadTemplate3.Name = "btcp_cxCadTemplate3";
            this.btcp_cxCadTemplate3.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxCadTemplate3.TabIndex = 13;
            this.btcp_cxCadTemplate3.Text = "Copiar";
            this.btcp_cxCadTemplate3.UseVisualStyleBackColor = false;
            this.btcp_cxCadTemplate3.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // cxCadNTemplate2
            // 
            this.cxCadNTemplate2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cxCadNTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadNTemplate2.Location = new System.Drawing.Point(403, 57);
            this.cxCadNTemplate2.Name = "cxCadNTemplate2";
            this.cxCadNTemplate2.ReadOnly = true;
            this.cxCadNTemplate2.Size = new System.Drawing.Size(17, 18);
            this.cxCadNTemplate2.TabIndex = 12;
            // 
            // cxCadTemplate2
            // 
            this.cxCadTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxCadTemplate2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxCadTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadTemplate2.Location = new System.Drawing.Point(420, 57);
            this.cxCadTemplate2.Name = "cxCadTemplate2";
            this.cxCadTemplate2.ReadOnly = true;
            this.cxCadTemplate2.Size = new System.Drawing.Size(294, 18);
            this.cxCadTemplate2.TabIndex = 12;
            // 
            // btcp_cxCadTemplate2
            // 
            this.btcp_cxCadTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxCadTemplate2.BackColor = System.Drawing.Color.White;
            this.btcp_cxCadTemplate2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxCadTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxCadTemplate2.Location = new System.Drawing.Point(719, 55);
            this.btcp_cxCadTemplate2.Name = "btcp_cxCadTemplate2";
            this.btcp_cxCadTemplate2.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxCadTemplate2.TabIndex = 13;
            this.btcp_cxCadTemplate2.Text = "Copiar";
            this.btcp_cxCadTemplate2.UseVisualStyleBackColor = false;
            this.btcp_cxCadTemplate2.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // cxCadNTemplate4
            // 
            this.cxCadNTemplate4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cxCadNTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadNTemplate4.Location = new System.Drawing.Point(403, 95);
            this.cxCadNTemplate4.Name = "cxCadNTemplate4";
            this.cxCadNTemplate4.ReadOnly = true;
            this.cxCadNTemplate4.Size = new System.Drawing.Size(17, 18);
            this.cxCadNTemplate4.TabIndex = 12;
            // 
            // cxCadTemplate4
            // 
            this.cxCadTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxCadTemplate4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxCadTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadTemplate4.Location = new System.Drawing.Point(420, 95);
            this.cxCadTemplate4.Name = "cxCadTemplate4";
            this.cxCadTemplate4.ReadOnly = true;
            this.cxCadTemplate4.Size = new System.Drawing.Size(294, 18);
            this.cxCadTemplate4.TabIndex = 12;
            // 
            // cxCadNTemplate5
            // 
            this.cxCadNTemplate5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cxCadNTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadNTemplate5.Location = new System.Drawing.Point(403, 114);
            this.cxCadNTemplate5.Name = "cxCadNTemplate5";
            this.cxCadNTemplate5.ReadOnly = true;
            this.cxCadNTemplate5.Size = new System.Drawing.Size(17, 18);
            this.cxCadNTemplate5.TabIndex = 12;
            // 
            // cxCadTemplate5
            // 
            this.cxCadTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxCadTemplate5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxCadTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxCadTemplate5.Location = new System.Drawing.Point(420, 114);
            this.cxCadTemplate5.Name = "cxCadTemplate5";
            this.cxCadTemplate5.ReadOnly = true;
            this.cxCadTemplate5.Size = new System.Drawing.Size(294, 18);
            this.cxCadTemplate5.TabIndex = 12;
            // 
            // btcp_cxCadTemplate1
            // 
            this.btcp_cxCadTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxCadTemplate1.BackColor = System.Drawing.Color.White;
            this.btcp_cxCadTemplate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxCadTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxCadTemplate1.Location = new System.Drawing.Point(719, 36);
            this.btcp_cxCadTemplate1.Name = "btcp_cxCadTemplate1";
            this.btcp_cxCadTemplate1.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxCadTemplate1.TabIndex = 13;
            this.btcp_cxCadTemplate1.Text = "Copiar";
            this.btcp_cxCadTemplate1.UseVisualStyleBackColor = false;
            this.btcp_cxCadTemplate1.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // QuantTemplatesLidos
            // 
            this.QuantTemplatesLidos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.QuantTemplatesLidos.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.QuantTemplatesLidos.Enabled = false;
            this.QuantTemplatesLidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantTemplatesLidos.Location = new System.Drawing.Point(681, 18);
            this.QuantTemplatesLidos.Name = "QuantTemplatesLidos";
            this.QuantTemplatesLidos.ReadOnly = true;
            this.QuantTemplatesLidos.Size = new System.Drawing.Size(33, 18);
            this.QuantTemplatesLidos.TabIndex = 12;
            // 
            // textoIMG
            // 
            this.textoIMG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textoIMG.AutoSize = true;
            this.textoIMG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoIMG.Location = new System.Drawing.Point(82, 119);
            this.textoIMG.Name = "textoIMG";
            this.textoIMG.Size = new System.Drawing.Size(0, 15);
            this.textoIMG.TabIndex = 7;
            this.textoIMG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(381, 15);
            this.label11.TabIndex = 7;
            this.label11.Text = "Converter templates concatenados(Tupã) para templates individuais:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(382, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Templates lidos";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(581, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 15);
            this.label12.TabIndex = 7;
            this.label12.Text = "Quant. templates:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(382, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 90);
            this.label2.TabIndex = 7;
            this.label2.Text = "1º:\r\n2º:\r\n3º:\r\n4º:\r\n5º:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.cxPorta);
            this.groupBox2.Controls.Add(this.cxCPF);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cxSenha);
            this.groupBox2.Controls.Add(this.cxIp);
            this.groupBox2.Controls.Add(this.cxNumSerie);
            this.groupBox2.Controls.Add(this.TxCopiado);
            this.groupBox2.Controls.Add(this.btcp_cxLerTemplate5);
            this.groupBox2.Controls.Add(this.btcp_cxLerTemplate4);
            this.groupBox2.Controls.Add(this.btcp_cxLerTemplate3);
            this.groupBox2.Controls.Add(this.btcp_cxLerTemplate2);
            this.groupBox2.Controls.Add(this.CpCL_cxGravarTemplate5);
            this.groupBox2.Controls.Add(this.CpCL_cxGravarTemplate4);
            this.groupBox2.Controls.Add(this.CpCL_cxGravarTemplate3);
            this.groupBox2.Controls.Add(this.CpCL_cxGravarTemplate2);
            this.groupBox2.Controls.Add(this.CpCL_cxGravarTemplate1);
            this.groupBox2.Controls.Add(this.btcp_cxLerTemplate1);
            this.groupBox2.Controls.Add(this.cxGravarTemplate5);
            this.groupBox2.Controls.Add(this.cxLerTemplate5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cxGravarTemplate4);
            this.groupBox2.Controls.Add(this.cxLerTemplate4);
            this.groupBox2.Controls.Add(this.cxGravarTemplate2);
            this.groupBox2.Controls.Add(this.cxLerTemplate2);
            this.groupBox2.Controls.Add(this.cxGravarTemplate3);
            this.groupBox2.Controls.Add(this.cxLerTemplate3);
            this.groupBox2.Controls.Add(this.cxGravarTemplate1);
            this.groupBox2.Controls.Add(this.cxLerTemplate1);
            this.groupBox2.Controls.Add(this.cxNumPIS);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.TBListaUsuarios);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btExportarFunc);
            this.groupBox2.Controls.Add(this.btExcluirUsuario);
            this.groupBox2.Controls.Add(this.verificarConexao);
            this.groupBox2.Controls.Add(this.btListarUsuarios);
            this.groupBox2.Controls.Add(this.btLerTempIndividual);
            this.groupBox2.Controls.Add(this.btLimparLer);
            this.groupBox2.Controls.Add(this.btLimparGravar);
            this.groupBox2.Controls.Add(this.btGravarTempIndividual);
            this.groupBox2.Controls.Add(this.btGravarTempConcatenado);
            this.groupBox2.Location = new System.Drawing.Point(12, 191);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(773, 445);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operações com o Kurumim REP3";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // cxPorta
            // 
            this.cxPorta.Location = new System.Drawing.Point(397, 66);
            this.cxPorta.MaxLength = 4;
            this.cxPorta.Name = "cxPorta";
            this.cxPorta.Size = new System.Drawing.Size(66, 20);
            this.cxPorta.TabIndex = 14;
            // 
            // cxCPF
            // 
            this.cxCPF.Location = new System.Drawing.Point(504, 43);
            this.cxCPF.Name = "cxCPF";
            this.cxCPF.Size = new System.Drawing.Size(99, 20);
            this.cxCPF.TabIndex = 14;
            this.cxCPF.Text = "11111111111";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 414);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(669, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // cxSenha
            // 
            this.cxSenha.Location = new System.Drawing.Point(397, 42);
            this.cxSenha.Name = "cxSenha";
            this.cxSenha.Size = new System.Drawing.Size(66, 20);
            this.cxSenha.TabIndex = 14;
            this.cxSenha.Text = "10000001";
            // 
            // cxIp
            // 
            this.cxIp.Location = new System.Drawing.Point(236, 65);
            this.cxIp.MaxLength = 16;
            this.cxIp.Name = "cxIp";
            this.cxIp.Size = new System.Drawing.Size(114, 20);
            this.cxIp.TabIndex = 14;
            // 
            // cxNumSerie
            // 
            this.cxNumSerie.Location = new System.Drawing.Point(236, 41);
            this.cxNumSerie.MaxLength = 17;
            this.cxNumSerie.Name = "cxNumSerie";
            this.cxNumSerie.Size = new System.Drawing.Size(114, 20);
            this.cxNumSerie.TabIndex = 14;
            this.cxNumSerie.Text = "00008003940900002";
            // 
            // TxCopiado
            // 
            this.TxCopiado.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TxCopiado.AutoSize = true;
            this.TxCopiado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxCopiado.ForeColor = System.Drawing.Color.Red;
            this.TxCopiado.Location = new System.Drawing.Point(483, 241);
            this.TxCopiado.Name = "TxCopiado";
            this.TxCopiado.Size = new System.Drawing.Size(83, 18);
            this.TxCopiado.TabIndex = 7;
            this.TxCopiado.Text = "COPIADO";
            this.TxCopiado.Visible = false;
            // 
            // btcp_cxLerTemplate5
            // 
            this.btcp_cxLerTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxLerTemplate5.BackColor = System.Drawing.Color.White;
            this.btcp_cxLerTemplate5.Enabled = false;
            this.btcp_cxLerTemplate5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxLerTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxLerTemplate5.Location = new System.Drawing.Point(719, 216);
            this.btcp_cxLerTemplate5.Name = "btcp_cxLerTemplate5";
            this.btcp_cxLerTemplate5.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxLerTemplate5.TabIndex = 13;
            this.btcp_cxLerTemplate5.Text = "Copiar";
            this.btcp_cxLerTemplate5.UseVisualStyleBackColor = false;
            this.btcp_cxLerTemplate5.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // btcp_cxLerTemplate4
            // 
            this.btcp_cxLerTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxLerTemplate4.BackColor = System.Drawing.Color.White;
            this.btcp_cxLerTemplate4.Enabled = false;
            this.btcp_cxLerTemplate4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxLerTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxLerTemplate4.Location = new System.Drawing.Point(719, 197);
            this.btcp_cxLerTemplate4.Name = "btcp_cxLerTemplate4";
            this.btcp_cxLerTemplate4.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxLerTemplate4.TabIndex = 13;
            this.btcp_cxLerTemplate4.Text = "Copiar";
            this.btcp_cxLerTemplate4.UseVisualStyleBackColor = false;
            this.btcp_cxLerTemplate4.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // btcp_cxLerTemplate3
            // 
            this.btcp_cxLerTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxLerTemplate3.BackColor = System.Drawing.Color.White;
            this.btcp_cxLerTemplate3.Enabled = false;
            this.btcp_cxLerTemplate3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxLerTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxLerTemplate3.Location = new System.Drawing.Point(719, 177);
            this.btcp_cxLerTemplate3.Name = "btcp_cxLerTemplate3";
            this.btcp_cxLerTemplate3.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxLerTemplate3.TabIndex = 13;
            this.btcp_cxLerTemplate3.Text = "Copiar";
            this.btcp_cxLerTemplate3.UseVisualStyleBackColor = false;
            this.btcp_cxLerTemplate3.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // btcp_cxLerTemplate2
            // 
            this.btcp_cxLerTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxLerTemplate2.BackColor = System.Drawing.Color.White;
            this.btcp_cxLerTemplate2.Enabled = false;
            this.btcp_cxLerTemplate2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxLerTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxLerTemplate2.Location = new System.Drawing.Point(719, 158);
            this.btcp_cxLerTemplate2.Name = "btcp_cxLerTemplate2";
            this.btcp_cxLerTemplate2.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxLerTemplate2.TabIndex = 13;
            this.btcp_cxLerTemplate2.Text = "Copiar";
            this.btcp_cxLerTemplate2.UseVisualStyleBackColor = false;
            this.btcp_cxLerTemplate2.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // CpCL_cxGravarTemplate5
            // 
            this.CpCL_cxGravarTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CpCL_cxGravarTemplate5.BackColor = System.Drawing.Color.White;
            this.CpCL_cxGravarTemplate5.Enabled = false;
            this.CpCL_cxGravarTemplate5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CpCL_cxGravarTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpCL_cxGravarTemplate5.Location = new System.Drawing.Point(719, 362);
            this.CpCL_cxGravarTemplate5.Name = "CpCL_cxGravarTemplate5";
            this.CpCL_cxGravarTemplate5.Size = new System.Drawing.Size(47, 21);
            this.CpCL_cxGravarTemplate5.TabIndex = 13;
            this.CpCL_cxGravarTemplate5.Text = "Colar";
            this.CpCL_cxGravarTemplate5.UseVisualStyleBackColor = false;
            this.CpCL_cxGravarTemplate5.Click += new System.EventHandler(this.CpCL_cxGravarTemplate1_Click);
            // 
            // CpCL_cxGravarTemplate4
            // 
            this.CpCL_cxGravarTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CpCL_cxGravarTemplate4.BackColor = System.Drawing.Color.White;
            this.CpCL_cxGravarTemplate4.Enabled = false;
            this.CpCL_cxGravarTemplate4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CpCL_cxGravarTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpCL_cxGravarTemplate4.Location = new System.Drawing.Point(719, 342);
            this.CpCL_cxGravarTemplate4.Name = "CpCL_cxGravarTemplate4";
            this.CpCL_cxGravarTemplate4.Size = new System.Drawing.Size(47, 21);
            this.CpCL_cxGravarTemplate4.TabIndex = 13;
            this.CpCL_cxGravarTemplate4.Text = "Colar";
            this.CpCL_cxGravarTemplate4.UseVisualStyleBackColor = false;
            this.CpCL_cxGravarTemplate4.Click += new System.EventHandler(this.CpCL_cxGravarTemplate1_Click);
            // 
            // CpCL_cxGravarTemplate3
            // 
            this.CpCL_cxGravarTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CpCL_cxGravarTemplate3.BackColor = System.Drawing.Color.White;
            this.CpCL_cxGravarTemplate3.Enabled = false;
            this.CpCL_cxGravarTemplate3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CpCL_cxGravarTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpCL_cxGravarTemplate3.Location = new System.Drawing.Point(719, 323);
            this.CpCL_cxGravarTemplate3.Name = "CpCL_cxGravarTemplate3";
            this.CpCL_cxGravarTemplate3.Size = new System.Drawing.Size(47, 21);
            this.CpCL_cxGravarTemplate3.TabIndex = 13;
            this.CpCL_cxGravarTemplate3.Text = "Colar";
            this.CpCL_cxGravarTemplate3.UseVisualStyleBackColor = false;
            this.CpCL_cxGravarTemplate3.Click += new System.EventHandler(this.CpCL_cxGravarTemplate1_Click);
            // 
            // CpCL_cxGravarTemplate2
            // 
            this.CpCL_cxGravarTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CpCL_cxGravarTemplate2.BackColor = System.Drawing.Color.White;
            this.CpCL_cxGravarTemplate2.Enabled = false;
            this.CpCL_cxGravarTemplate2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CpCL_cxGravarTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpCL_cxGravarTemplate2.Location = new System.Drawing.Point(719, 304);
            this.CpCL_cxGravarTemplate2.Name = "CpCL_cxGravarTemplate2";
            this.CpCL_cxGravarTemplate2.Size = new System.Drawing.Size(47, 21);
            this.CpCL_cxGravarTemplate2.TabIndex = 13;
            this.CpCL_cxGravarTemplate2.Text = "Colar";
            this.CpCL_cxGravarTemplate2.UseVisualStyleBackColor = false;
            this.CpCL_cxGravarTemplate2.Click += new System.EventHandler(this.CpCL_cxGravarTemplate1_Click);
            // 
            // CpCL_cxGravarTemplate1
            // 
            this.CpCL_cxGravarTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CpCL_cxGravarTemplate1.BackColor = System.Drawing.Color.White;
            this.CpCL_cxGravarTemplate1.Enabled = false;
            this.CpCL_cxGravarTemplate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CpCL_cxGravarTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpCL_cxGravarTemplate1.Location = new System.Drawing.Point(719, 286);
            this.CpCL_cxGravarTemplate1.Name = "CpCL_cxGravarTemplate1";
            this.CpCL_cxGravarTemplate1.Size = new System.Drawing.Size(47, 21);
            this.CpCL_cxGravarTemplate1.TabIndex = 13;
            this.CpCL_cxGravarTemplate1.Text = "Colar";
            this.CpCL_cxGravarTemplate1.UseVisualStyleBackColor = false;
            this.CpCL_cxGravarTemplate1.Click += new System.EventHandler(this.CpCL_cxGravarTemplate1_Click);
            // 
            // btcp_cxLerTemplate1
            // 
            this.btcp_cxLerTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btcp_cxLerTemplate1.BackColor = System.Drawing.Color.White;
            this.btcp_cxLerTemplate1.Enabled = false;
            this.btcp_cxLerTemplate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btcp_cxLerTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btcp_cxLerTemplate1.Location = new System.Drawing.Point(719, 139);
            this.btcp_cxLerTemplate1.Name = "btcp_cxLerTemplate1";
            this.btcp_cxLerTemplate1.Size = new System.Drawing.Size(47, 21);
            this.btcp_cxLerTemplate1.TabIndex = 13;
            this.btcp_cxLerTemplate1.Text = "Copiar";
            this.btcp_cxLerTemplate1.UseVisualStyleBackColor = false;
            this.btcp_cxLerTemplate1.Click += new System.EventHandler(this.btcp_cxLerTemplate1_Click);
            // 
            // cxGravarTemplate5
            // 
            this.cxGravarTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxGravarTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxGravarTemplate5.Location = new System.Drawing.Point(236, 363);
            this.cxGravarTemplate5.Name = "cxGravarTemplate5";
            this.cxGravarTemplate5.Size = new System.Drawing.Size(478, 18);
            this.cxGravarTemplate5.TabIndex = 12;
            // 
            // cxLerTemplate5
            // 
            this.cxLerTemplate5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxLerTemplate5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxLerTemplate5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxLerTemplate5.Location = new System.Drawing.Point(236, 217);
            this.cxLerTemplate5.Name = "cxLerTemplate5";
            this.cxLerTemplate5.ReadOnly = true;
            this.cxLerTemplate5.Size = new System.Drawing.Size(478, 18);
            this.cxLerTemplate5.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(209, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(284, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Leia os templates do usuario para o campo abaixo";
            // 
            // cxGravarTemplate4
            // 
            this.cxGravarTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxGravarTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxGravarTemplate4.Location = new System.Drawing.Point(236, 344);
            this.cxGravarTemplate4.Name = "cxGravarTemplate4";
            this.cxGravarTemplate4.Size = new System.Drawing.Size(478, 18);
            this.cxGravarTemplate4.TabIndex = 12;
            // 
            // cxLerTemplate4
            // 
            this.cxLerTemplate4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxLerTemplate4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxLerTemplate4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxLerTemplate4.Location = new System.Drawing.Point(236, 198);
            this.cxLerTemplate4.Name = "cxLerTemplate4";
            this.cxLerTemplate4.ReadOnly = true;
            this.cxLerTemplate4.Size = new System.Drawing.Size(478, 18);
            this.cxLerTemplate4.TabIndex = 12;
            // 
            // cxGravarTemplate2
            // 
            this.cxGravarTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxGravarTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxGravarTemplate2.Location = new System.Drawing.Point(236, 306);
            this.cxGravarTemplate2.Name = "cxGravarTemplate2";
            this.cxGravarTemplate2.Size = new System.Drawing.Size(478, 18);
            this.cxGravarTemplate2.TabIndex = 12;
            // 
            // cxLerTemplate2
            // 
            this.cxLerTemplate2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxLerTemplate2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxLerTemplate2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxLerTemplate2.Location = new System.Drawing.Point(236, 160);
            this.cxLerTemplate2.Name = "cxLerTemplate2";
            this.cxLerTemplate2.ReadOnly = true;
            this.cxLerTemplate2.Size = new System.Drawing.Size(478, 18);
            this.cxLerTemplate2.TabIndex = 12;
            // 
            // cxGravarTemplate3
            // 
            this.cxGravarTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxGravarTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxGravarTemplate3.Location = new System.Drawing.Point(236, 325);
            this.cxGravarTemplate3.Name = "cxGravarTemplate3";
            this.cxGravarTemplate3.Size = new System.Drawing.Size(478, 18);
            this.cxGravarTemplate3.TabIndex = 12;
            // 
            // cxLerTemplate3
            // 
            this.cxLerTemplate3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxLerTemplate3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxLerTemplate3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxLerTemplate3.Location = new System.Drawing.Point(236, 179);
            this.cxLerTemplate3.Name = "cxLerTemplate3";
            this.cxLerTemplate3.ReadOnly = true;
            this.cxLerTemplate3.Size = new System.Drawing.Size(478, 18);
            this.cxLerTemplate3.TabIndex = 12;
            // 
            // cxGravarTemplate1
            // 
            this.cxGravarTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxGravarTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxGravarTemplate1.Location = new System.Drawing.Point(236, 287);
            this.cxGravarTemplate1.Name = "cxGravarTemplate1";
            this.cxGravarTemplate1.Size = new System.Drawing.Size(478, 18);
            this.cxGravarTemplate1.TabIndex = 12;
            // 
            // cxLerTemplate1
            // 
            this.cxLerTemplate1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cxLerTemplate1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cxLerTemplate1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxLerTemplate1.Location = new System.Drawing.Point(236, 141);
            this.cxLerTemplate1.Name = "cxLerTemplate1";
            this.cxLerTemplate1.ReadOnly = true;
            this.cxLerTemplate1.Size = new System.Drawing.Size(478, 18);
            this.cxLerTemplate1.TabIndex = 12;
            // 
            // cxNumPIS
            // 
            this.cxNumPIS.Location = new System.Drawing.Point(322, 91);
            this.cxNumPIS.Name = "cxNumPIS";
            this.cxNumPIS.Size = new System.Drawing.Size(141, 20);
            this.cxNumPIS.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Location = new System.Drawing.Point(196, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 384);
            this.panel1.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(209, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(213, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Grave os templates abaixo no usuário";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(212, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 15);
            this.label16.TabIndex = 7;
            this.label16.Text = "IP:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(212, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 15);
            this.label14.TabIndex = 7;
            this.label14.Text = "NS:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(470, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 15);
            this.label15.TabIndex = 7;
            this.label15.Text = "CPF:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(354, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 15);
            this.label13.TabIndex = 7;
            this.label13.Text = "Senha:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(354, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Porta:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(212, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "PIS do funcionário:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(212, 288);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 90);
            this.label10.TabIndex = 7;
            this.label10.Text = "1º:\r\n2º:\r\n3º:\r\n4º:\r\n5º:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(212, 147);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 90);
            this.label9.TabIndex = 7;
            this.label9.Text = "1º:\r\n2º:\r\n3º:\r\n4º:\r\n5º:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(213, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(137, 15);
            this.label17.TabIndex = 7;
            this.label17.Text = "Dados de comunicação";
            // 
            // btExportarFunc
            // 
            this.btExportarFunc.BackColor = System.Drawing.Color.Honeydew;
            this.btExportarFunc.Enabled = false;
            this.btExportarFunc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExportarFunc.Location = new System.Drawing.Point(9, 386);
            this.btExportarFunc.Name = "btExportarFunc";
            this.btExportarFunc.Size = new System.Drawing.Size(173, 23);
            this.btExportarFunc.TabIndex = 8;
            this.btExportarFunc.Text = "Exportar Funcionarios.prv";
            this.btExportarFunc.UseVisualStyleBackColor = false;
            this.btExportarFunc.Click += new System.EventHandler(this.btExportarFunc_Click);
            // 
            // btExcluirUsuario
            // 
            this.btExcluirUsuario.BackColor = System.Drawing.Color.White;
            this.btExcluirUsuario.Enabled = false;
            this.btExcluirUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExcluirUsuario.Location = new System.Drawing.Point(9, 362);
            this.btExcluirUsuario.Name = "btExcluirUsuario";
            this.btExcluirUsuario.Size = new System.Drawing.Size(173, 23);
            this.btExcluirUsuario.TabIndex = 8;
            this.btExcluirUsuario.Text = "Excluir digitais func. Selecionado";
            this.btExcluirUsuario.UseVisualStyleBackColor = false;
            this.btExcluirUsuario.Click += new System.EventHandler(this.btExcluirUsuario_Click);
            // 
            // verificarConexao
            // 
            this.verificarConexao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.verificarConexao.BackColor = System.Drawing.Color.White;
            this.verificarConexao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.verificarConexao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verificarConexao.ForeColor = System.Drawing.Color.Green;
            this.verificarConexao.Location = new System.Drawing.Point(624, 41);
            this.verificarConexao.Name = "verificarConexao";
            this.verificarConexao.Size = new System.Drawing.Size(142, 70);
            this.verificarConexao.TabIndex = 8;
            this.verificarConexao.Text = "Iniciar e verificar\r\nconexão";
            this.verificarConexao.UseVisualStyleBackColor = false;
            this.verificarConexao.Click += new System.EventHandler(this.verificarConexao_Click);
            // 
            // btLimparLer
            // 
            this.btLimparLer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btLimparLer.BackColor = System.Drawing.Color.White;
            this.btLimparLer.Enabled = false;
            this.btLimparLer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLimparLer.Location = new System.Drawing.Point(572, 240);
            this.btLimparLer.Name = "btLimparLer";
            this.btLimparLer.Size = new System.Drawing.Size(82, 23);
            this.btLimparLer.TabIndex = 1;
            this.btLimparLer.Text = "Limpar";
            this.btLimparLer.UseVisualStyleBackColor = false;
            this.btLimparLer.Click += new System.EventHandler(this.button2_Click);
            // 
            // btLimparGravar
            // 
            this.btLimparGravar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btLimparGravar.BackColor = System.Drawing.Color.White;
            this.btLimparGravar.Enabled = false;
            this.btLimparGravar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLimparGravar.Location = new System.Drawing.Point(572, 386);
            this.btLimparGravar.Name = "btLimparGravar";
            this.btLimparGravar.Size = new System.Drawing.Size(82, 23);
            this.btLimparGravar.TabIndex = 1;
            this.btLimparGravar.Text = "Limpar";
            this.btLimparGravar.UseVisualStyleBackColor = false;
            this.btLimparGravar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btGravarTempConcatenado
            // 
            this.btGravarTempConcatenado.BackColor = System.Drawing.Color.White;
            this.btGravarTempConcatenado.Enabled = false;
            this.btGravarTempConcatenado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGravarTempConcatenado.Location = new System.Drawing.Point(216, 386);
            this.btGravarTempConcatenado.Name = "btGravarTempConcatenado";
            this.btGravarTempConcatenado.Size = new System.Drawing.Size(185, 23);
            this.btGravarTempConcatenado.TabIndex = 1;
            this.btGravarTempConcatenado.Text = "Gravar Templates concatenados**";
            this.btGravarTempConcatenado.UseVisualStyleBackColor = false;
            this.btGravarTempConcatenado.Click += new System.EventHandler(this.btGravarTempConcatenado_Click);
            this.btGravarTempConcatenado.MouseLeave += new System.EventHandler(this.btGravarTempConcatenado_MouseLeave);
            this.btGravarTempConcatenado.MouseHover += new System.EventHandler(this.btGravarTempConcatenado_MouseHover);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "prv";
            this.saveFileDialog1.Filter = "Arquivo Proveu (*.prv)|*.prv|Qualquer arquivo (*.*)|*.*";
            // 
            // GerenciarDigitaisREP3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Teste_Gerenciamento_de_Digitais_REP3.Properties.Resources.fundo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 652);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1366, 690);
            this.MinimumSize = new System.Drawing.Size(806, 690);
            this.Name = "GerenciarDigitaisREP3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desmontrativo de gerenciamento individual de digitais REP3";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GerenciarDigitaisTupa2_FormClosed);
            this.Load += new System.EventHandler(this.GerenciarDigitaisTupa2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TBListaUsuarios)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btLerTempIndividual;
        private System.Windows.Forms.Button btGravarTempIndividual;
        private System.Windows.Forms.DataGridView TBListaUsuarios;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btListarUsuarios;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox cxNumPIS;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox cxGravarTemplate5;
        private System.Windows.Forms.TextBox cxLerTemplate5;
        private System.Windows.Forms.TextBox cxGravarTemplate4;
        private System.Windows.Forms.TextBox cxLerTemplate4;
        private System.Windows.Forms.TextBox cxGravarTemplate2;
        private System.Windows.Forms.TextBox cxLerTemplate2;
        private System.Windows.Forms.TextBox cxGravarTemplate3;
        private System.Windows.Forms.TextBox cxLerTemplate3;
        private System.Windows.Forms.TextBox cxGravarTemplate1;
        private System.Windows.Forms.TextBox cxLerTemplate1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btExcluirUsuario;
        private System.Windows.Forms.Button btcp_cxLerTemplate1;
        private System.Windows.Forms.Button btcp_cxLerTemplate5;
        private System.Windows.Forms.Button btcp_cxLerTemplate4;
        private System.Windows.Forms.Button btcp_cxLerTemplate3;
        private System.Windows.Forms.Button btcp_cxLerTemplate2;
        private System.Windows.Forms.Button CpCL_cxGravarTemplate1;
        private System.Windows.Forms.Button CpCL_cxGravarTemplate5;
        private System.Windows.Forms.Button CpCL_cxGravarTemplate4;
        private System.Windows.Forms.Button CpCL_cxGravarTemplate3;
        private System.Windows.Forms.Button CpCL_cxGravarTemplate2;
        private System.Windows.Forms.Label TxCopiado;
        private System.Windows.Forms.Button btLimparLer;
        private System.Windows.Forms.Button btLimparGravar;
        private System.Windows.Forms.TextBox cxCadTemplate1;
        private System.Windows.Forms.Button btcp_cxCadTemplate5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btcp_cxCadTemplate4;
        private System.Windows.Forms.TextBox cxCadTemplate3;
        private System.Windows.Forms.Button btcp_cxCadTemplate3;
        private System.Windows.Forms.TextBox cxCadTemplate2;
        private System.Windows.Forms.Button btcp_cxCadTemplate2;
        private System.Windows.Forms.TextBox cxCadTemplate4;
        private System.Windows.Forms.TextBox cxCadTemplate5;
        private System.Windows.Forms.Button btcp_cxCadTemplate1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox QuantTemplatesLidos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label textoIMG;
        private System.Windows.Forms.TextBox cxCadNTemplate1;
        private System.Windows.Forms.TextBox cxCadNTemplate3;
        private System.Windows.Forms.TextBox cxCadNTemplate2;
        private System.Windows.Forms.TextBox cxCadNTemplate4;
        private System.Windows.Forms.TextBox cxCadNTemplate5;
        private System.Windows.Forms.Button btGravarTempConcatenado;
        private System.Windows.Forms.TextBox cxPorta;
        private System.Windows.Forms.TextBox cxCPF;
        private System.Windows.Forms.TextBox cxSenha;
        private System.Windows.Forms.TextBox cxIp;
        private System.Windows.Forms.TextBox cxNumSerie;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button verificarConexao;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ncracha;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuantTemplates;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btExportarFunc;
        private System.Windows.Forms.TextBox campoTemplateConcatenado;
        private System.Windows.Forms.Button btconverter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

