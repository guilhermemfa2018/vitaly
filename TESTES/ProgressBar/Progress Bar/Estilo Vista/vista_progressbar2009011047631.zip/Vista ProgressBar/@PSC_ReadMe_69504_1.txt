Title: Vista progress bars collection
Description: A set of useful progressbars with the vista style. 
	* Crystal effect which moves thru the progress bar
	* Green &amp; Red colored progress bar
	* Calculting progress bar
	* Two sizes
	
My special thanks goes to people who build the stuff earlier
Keywords: vista progressbar aero big crystal controls manifest style Prog animate large small calculating keith wickramasekara progress
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69504&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
